/* Version 1.5.0 */
/* https://community.servicenow.com/message/1152333 */

function($rootScope, $scope, $http, spUtil, $timeout) {
	var c_this = this;
	
	$scope.data.calListColumns = 5; // Initializer (Default: 5)
	
	$scope.buildCalendarListView_CalSel = function()
	{
		var mainDiv = document.getElementById('mainCalSelDIV');

		if (!mainDiv)
		{
			alert("No table found!");
			return;
		}

		var newRow = false;
		var tr, td, url, html, calName, img, aDiv, imgDiv, md;

		var tbl = document.createElement('table');
		tbl.className = "tblStyle_CalSel";
		mainDiv.appendChild(tbl);

		for (var i = 0; i < $scope.data.calendars.length; i++)
		{
			newRow = false;
			calName = $scope.data.calendars[i].calTitle.replace(' On-Call', '');
			
			if ((i % $scope.data.calListColumns) == 0)
				newRow = true;

			if (newRow)
				tr = document.createElement('tr');

			url = $scope.data.spURL + '?id=snsp_cal_-_calendar&sysparm_calID=' + $scope.data.calendars[i].calID;

			td = document.createElement('td');
			aDiv = document.createElement('div');
			imgDiv = document.createElement('div');
			md = document.createElement('div');

			
			var aDiv_id = "aDiv_" + i.toString() + '';
			var td_id = "td_" + i.toString() + '';
			var md_id = "md_" + i.toString() + '';
			var imgDiv_id = "imgDiv_" + i.toString() + '';
			
			td.id = td_id;
			md.id = md_id;

			img = "url('" + $scope.data.calendars[i].image + "')";

			if (tr)
				tr.appendChild(td);

			aDiv.textContent = calName;
			aDiv.className = "aDivStyle_CalSel";

			aDiv.id = aDiv_id;
			imgDiv.id = imgDiv_id;
			imgDiv.className = "imgDivStyle_CalSel grow_CalSel";
			md.setAttribute('calURL', url);
			md.onclick = function(){$scope.redirectToCalendar(this);};
			md.onmouseover = function(){$scope.onHover_CalSel(this, 1);};
			md.onmouseout = function(){$scope.onHover_CalSel(this, 0);};
			md.className = "mdStyle_CalSel";

			td.className = "tdStyle_CalSel";
			imgDiv.style.backgroundImage = img;

			if (newRow)
				tbl.appendChild(tr);

			md.appendChild(aDiv);
			md.appendChild(imgDiv);
			td.appendChild(md);
		}
	};

	$scope.redirectToCalendar = function(whichCal)
	{
		
			var m = document.getElementById('masterBodyDiv');
			var cs = document.getElementById('mainCalSelDIV');
			if (m && cs)
			{
				cs.style.display = "none";
				m.innerHTML = "<h1>...loading calendar</h1>";
				m.style.cssText = "text-align:center;margin-top:50px;";
			}
			window.location.href = whichCal.getAttribute('calURL');
		
	};

	$scope.onHover_CalSel = function(e, inOut)
	{
		if (e)
		{
			var aDiv = document.getElementById("aDiv_"+e.id.split('_')[1]);
			if (aDiv)
			{
				if (inOut == 0)
				{
					if (aDiv.classList.contains('aDiv_hover_CalSel'))
						aDiv.classList.remove('aDiv_hover_CalSel');
					if (aDiv.classList.contains('aDiv_unhover_CalSel'))
					{}
					else
						aDiv.classList.add('aDiv_unhover_CalSel');
				}
				if (inOut == 1)
				{
					if (aDiv.classList.contains('aDiv_unhover_CalSel'))
						aDiv.classList.remove('aDiv_unhover_CalSel');
					if (aDiv.classList.contains('aDiv_hover_CalSel'))
					{}
					else
						aDiv.classList.add('aDiv_hover_CalSel');
				}
			}
		}
	};
}