/*  Version 1.5.0
https://community.servicenow.com/message/1152333
*/

(function() {
	var spURL = gs.getProperty('glide.servlet.uri') + "sp";
	var calendars = [];
	gr = new GlideRecord('u_sp_calendar_listings');
	gr.addQuery('u_appear_on_list', 'true');
	gr.orderBy('u_calendar_id');
	gr.query();
	while (gr.next())
	{
		calendars.push({
			image:gr.u_image.name.toString(),
			calID:gr.u_calendar_id.toString(),
			calTitle:gr.u_calendar_title.toString()
		})
	}
	data.calendars = calendars;
	data.spURL = spURL;
})();