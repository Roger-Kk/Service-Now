/* Version 1.5.1 */
/* https://community.servicenow.com/message/1152333 */

function($rootScope, $scope, $http, spUtil, $timeout, $location, $compile, $element) {
	var c_this = this;
	
	var searchObject = $location.search();
	
	
	$scope.getCalID = function()
	{
		$scope.data.locationURL_CalVal = searchObject.sysparm_calID;
		c_this.data.locationURL_CalVal = searchObject.sysparm_calID;
		c_this.data.RUNMEFIRST = true;
		c_this.server.update().then(function(response) {
			c_this.data.RUNMEFIRST = false;
			$scope.buildCalendarListView_CalSel();
		});
	};

	/***************************************************************
	The version of jQuery that FullCalendar is using has deprecated the jQuery.unload() function.
	This is as of jQuery v3.0 (https://api.jquery.com/unload/)
	https://community.servicenow.com/message/1212609#1212609
***************************************************************/
	//	spUtil.recordWatch($scope, "u_sp_calendar", "", function(name, data) {
	//		$('#calendar').fullCalendar('refetchEvents');
	//	});

	var theEventArray; // Every time events are added/changed/removed from the calendar, this array gets updated with the event information.
	var tOut; // setTimeout reference variable
	var jsc; // set in $scope.initializeColorPicker function
	var colorTIMEOUT; // setTimeout reference variable
	var ALT_key_down = false; // Listener to detect ALT key press.  Changes to 'true' when ALT key is pressed.

	
/*
					USER CONFIGURABLE OPTIONS ----  BEGIN
*/
	$scope.data.editButton_EDIT = "edit";  // Initializer (Default: edit)
	$scope.data.edibButton_STOP = "Stop Editing";  // Initializer (Default: Stop Editing)
	$scope.data.editButtonStatus = $scope.data.editButton_EDIT;
	$scope.displayInstructions = false; // Initializer (Default: false)
	$scope.displayCategoryMenu = false; // Initializer (Default: false)
	$scope.defaultCategorySelectOption = '-- Category --'; // Initializer (Default: -- Category --)
	$scope.data.calendarCanBeEdited = false; // Initializer (Default: false)
	$scope.data.howManyQuickAccessEvents = 0; // Initializer (Default: 0)
	$scope.data.viewRatio = 'standard'; // Initializer (Default: standard)
	$scope.data.titlePaddingLeft = 200; // Centers the calendar title over the calendar.  Adjust as needed.  (Default: 200)
	$scope.data.droppedEvent_bgc = ''; // Initializer (Default: '')
	$scope.data.droppedEvent_fgc = ''; // Initializer (Default: '')
	$scope.data.defaultEventBackgroundColor = '#3A87AD'; // Default event color in fullcalendar.css (Default: #3A87AD)
	$scope.data.createNewEventDateDisplay = ''; // Initializer (Default: '')
	$scope.data.newEvent_start = ''; // Initializer (Default: '')
	$scope.data.newEvent_end = ''; // Initializer (Default: '')
	$scope.data.newEventTriggered = false; // Initializer (Default: false)
	$scope.data.calListColumns = 6; // Initializer (Default: 6)
	$scope.data.EventUser_sysID = ''; // Initializer (Default: '')
	$scope.data.EventUser_name = ''; // Initializer (Default: '')

	// Data used to build the <sn-record-picker> in the function, $scope.build_recordPicker_for_user_table
	$scope.data.snrp_TABLE = 'sys_user';
	$scope.data.snrp_QUERY = 'u_dnLIKEAmerica^ORu_dnLIKEEurope^active=true';
	$scope.data.snrp_DISPLAY = 'name';
	$scope.data.snrp_VALUE = 'sys_id';
	$scope.data.snrp_SEARCH = 'name';
	$scope.data.snrp_SIZE = '5';
/*
					USER CONFIGURABLE OPTIONS ----  END
*/
	

	$scope.EventUser = {  
		displayValue: '',  
		value: '',  
		name: 'EventUser'  
	};

	$scope.EventUser_Change = {  
		displayValue: '',  
		value: '',  
		name: 'EventUser_Change'  
	};
	
	$scope.$on("field.change", function(evt, parms) {
		if (parms.field.name == 'EventUser' || parms.field.name == 'EventUser_Change')
		{
			$scope.data.EventUser_sysID = parms.newValue.toString().trim();
			$scope.data.EventUser_name = parms.displayValue.toString().trim();
			
			try{document.getElementById('new_eventName').value = $scope.data.EventUser_name;}catch(e){console.warn(e.message);}

			console.info("$scope.data.EventUser_sysID: " + $scope.data.EventUser_sysID);
			console.info("$scope.data.EventUser_name: " + $scope.data.EventUser_name);
		}
	});

	// It's what kicks the whole thing off.
	$scope.tmo = function()
	{
		// Calls the function to initialize the calendar after .1 seconds
		tOut = setTimeout(function(){ $scope.initializeCalendar() }, 100);
		// Add keyboard event listeners to detect the pressing of the ALT key.
		document.addEventListener("keydown", function(zEvent) {	if (zEvent.altKey) { ALT_key_down = true; } else { ALT_key_down = false; }});
		document.addEventListener("keyup", function(zEvent) {	ALT_key_down = false;	});
	};
	
	$scope.build_recordPicker_for_user_table = function(calEvent)
	{
		var change_userTF = '<sn-record-picker ';
		change_userTF += 'field="EventUser_Change"';
		change_userTF += 'table="data.snrp_TABLE"';
		change_userTF += 'default-query="data.snrp_QUERY"';
		change_userTF += 'display-field="data.snrp_DISPLAY"';
		change_userTF += 'value-field="data.snrp_VALUE"';
		change_userTF += 'search-fields="data.snrp_SEARCH"';
		change_userTF += 'page-size="data.snrp_SIZE"';
		change_userTF += '></sn-record-picker>';

		var el = $compile(change_userTF)($scope);
		var md = document.getElementById('div_userTF');
		$element.append(el);
		var snrp = $element[0].lastChild;
		if (snrp && md)
		{
			$element[0].removeChild($element[0].lastChild);
			md.appendChild(snrp);

			var dv = '';
			var v = '';
			if (calEvent.userSysID.toString().length)
			{
				dv = calEvent.title;
				v = calEvent.userSysID;
				
				// Category part of the title? Rip it out!
				dv = dv.replace('['+calEvent.category+'] ', '');

				try{ 
					document.getElementById('change_event_name_userCB').checked = true;
					document.getElementById('div_userTF').style.display = "";
					document.getElementById('input_u_new_title').style.display = "none";
				}catch(e){console.warn(e.message);}
			}
			
			$scope.data.EventUser_name = dv;
			$scope.data.EventUser_sysID = v;
			console.info("$scope.data.EventUser_sysID = v;: " + $scope.data.EventUser_sysID);

			$scope.EventUser_Change = {  
				displayValue: dv,  
				value: v,  
				name: 'EventUser_Change'  
			};
		}
	};

	// When a quick access event is created/changed/removed, this function counts how many are finally listed.
	$scope.setHowManyQuickAccessEvents = function()
	{
		var c = 0;
		var d = document.getElementsByTagName('div');
		for (var i = 0; i < d.length; i++)
		{
			if (d[i].id && d[i].id.indexOf('qae_') == 0 && d[i].className.indexOf('fc-event') >= 0)
				c++;
		}
		$scope.data.howManyQuickAccessEvents = c;
	};

	$scope.clearEventWordWrapping = function()
	{
		var d = document.getElementsByTagName('div');
		for (var i = 0; i < d.length; i++)
		{
			if (d[i].className.indexOf('fc-content') >= 0)
			{
				if (d[i].className.indexOf('fc-content-wrap-override') >= 0)
					continue;
				else
					d[i].classList.add('fc-content-wrap-override');
			}
		}
	};

	$scope.xfer_QA_color_TO_event = function(event)
	{
		var d = document.getElementsByTagName('div');
		for (var i = 0; i < d.length; i++)
		{
			if (d[i].id && d[i].id.indexOf('qae_') == 0 && d[i].className.indexOf('fc-event') >= 0)
			{
				if (d[i].innerHTML.trim() == event.innerText.trim())
				{
					$scope.data.droppedEvent_bgc = d[i].style.backgroundColor;
					$scope.data.droppedEvent_fgc = d[i].style.color;
				}
			}
		}
	};

	$scope.toggleCalendarEditMode = function()
	{
		if ($scope.data.mySysID == $scope.data.personEditingSysID)
			$scope.data.calendarCanBeEdited = true;
		else if (!$scope.data.inEditMod && !$scope.data.personEditingSysID)
			$scope.data.calendarCanBeEdited = true;

		// This overrides all
		if (!$scope.data.hasEditRole)
		{
			$scope.data.calendarCanBeEdited = false;
			$('#calendar').fullCalendar('option', 'selectable', false);
			$('#calendar').fullCalendar('option', 'editable', false);
			$('#calendar').fullCalendar('option', 'droppable', false);
			return;
		}

		if (!$scope.data.calendarCanBeEdited || $scope.data.editButtonStatus == $scope.data.edibButton_STOP)
		{
			$('#calendar').fullCalendar('option', 'selectable', false);
			$('#calendar').fullCalendar('option', 'editable', false);
			$('#calendar').fullCalendar('option', 'droppable', false);
			$scope.data.editButtonStatus = 'edit';
		}
		else if ($scope.data.calendarCanBeEdited && $scope.data.editButtonStatus == 'edit')
		{
			$('#calendar').fullCalendar('option', 'selectable', true);
			$('#calendar').fullCalendar('option', 'editable', true);
			$('#calendar').fullCalendar('option', 'droppable', true);
			$scope.data.editButtonStatus = $scope.data.edibButton_STOP;
		}
		$scope.changeEditButton();
	};

	// This check only happens after the Calendar is first initialized
	$scope.check_if_I_am_editing = function()
	{
		console.info("$scope.data.mySysID: " + $scope.data.mySysID);
		console.info("$scope.data.personEditingSysID: " + $scope.data.personEditingSysID);
		console.info("$scope.data.amIediting: " + $scope.data.amIediting);
		if ($scope.data.mySysID == $scope.data.personEditingSysID && $scope.data.amIediting)
		{
			c_this.data.toggleEditMode = "forcedStopEdit";
			c_this.data.locationURL_CalVal = $scope.data.locationURL_CalVal;
			c_this.server.update().then(function(response) {
				c_this.data.calUpdate = '';
				if (c_this.data.serverUpdateResponse)
					alert(c_this.data.serverUpdateResponse);
				c_this.data.serverUpdateResponse = '';
				c_this.data.toggleEditMode = '';
				console.info("c_this.server.update(): $scope.check_if_I_am_editing");
			});
		}
		// Remove the edit button if not authorized to edit
		if (!$scope.data.hasEditRole)
		{	
			try
			{
				var b = document.getElementsByClassName('fc-edit_button-button')[0];
				if (b)
					b.parentNode.removeChild(b);
			} catch(err) { console.warn("[WARNING:35346] " + err.message); }
		} 
	};

	$scope.editButtonClicked = function(t)
	{
		$scope.cancelColorChange();
		$scope.cancelNewEventAdd();
		c_this.data.locationURL_CalVal = $scope.data.locationURL_CalVal;
		c_this.server.update().then(function(response) {
			c_this.data.calUpdate = '';
			if (c_this.data.serverUpdateResponse)
				alert(c_this.data.serverUpdateResponse + "     [ERROR:782056]");
			c_this.data.toggleEditMode = '';
			if (!c_this.data.serverUpdateResponse)
				$scope.toggleCalendarEditMode(); // This resets the edit button, which sucks
			c_this.data.serverUpdateResponse = '';
			$scope.clearEventWordWrapping();
			console.info("c_this.server.update(): $scope.editButtonClicked");
		});
	};

	$scope.editingCalendar_updateDatabase = function()
	{
		c_this.data.toggleEditMode = "enter";
		c_this.data.locationURL_CalVal = $scope.data.locationURL_CalVal;
		c_this.server.update().then(function(response) {
			c_this.data.calUpdate = '';
			if (c_this.data.serverUpdateResponse)
				alert(c_this.data.serverUpdateResponse + "     [ERROR:323787]");
			c_this.data.serverUpdateResponse = '';
			c_this.data.toggleEditMode = '';
			console.info("c_this.server.update(): $scope.editingCalendar_updateDatabase");
		});
	};

	$scope.toggleTheHelpButton = function(t)
	{
		var h = document.getElementsByClassName('fc-hideInstructions_button-button');
		if (t == "on")
		{
			if (h && h[0]) { h[0].style.display = ''; }
		}
		else if (t == "off")
		{
			if (h && h[0])
			{
				h[0].style.display = 'none';
				$scope.displayInstructions = false;
				try { document.getElementById('instructions').style.display = "none";} catch(err) { console.warn("[WARNING:575046] " + err.message); }
			}
		}
	};

	$scope.toggleTheCategoryButton = function(t)
	{
		var h = document.getElementsByClassName('fc-category_button-button');
		if (t == "on")
		{
			if (h && h[0]) { h[0].style.display = ''; }
		}
		else if (t == "off")
		{
			if (h && h[0])
			{
				h[0].style.display = 'none';
				$scope.displayCategoryMenu = false;
				$scope.categoryMenu_Cancel();
			}
		}
	};
	
	$scope.newEvent_pickEvent_CB_checkBox_clicked = function($event)
	{
		var e = $event.currentTarget;
		if (e)
		{
			if (e.checked)
			{
				document.getElementById('newEvent_pickUser').style.display = '';
				document.getElementById('newEvent_customName').style.display = 'none';
				document.getElementById('new_eventName').value = '';
			}
			else
			{
				document.getElementById('newEvent_pickUser').style.display = 'none';
				document.getElementById('newEvent_customName').style.display = '';
				document.getElementById('new_eventName').value = '';
				$scope.data.EventUser_sysID = '';
				$scope.data.EventUser_name = '';
			}
		}
	};

	$scope.editExistingCategory_checkBox_clicked = function($event)
	{
		var e = $event.currentTarget;
		var tr = document.getElementById('editExistingCategory_TR');

		// First, remove all tr children
		if (tr)
			while (tr.firstChild)
				tr.removeChild(tr.firstChild);

		if (e)
		{
			if (e.checked)
			{
				try {
					document.getElementById('new_category').value = '';
					document.getElementById('new_categoryColor').value = 'FFFFFF';
					document.getElementById('catMenuTR1').style.display = 'none';
					document.getElementById('catMenuTR2').style.display = 'none';
					document.getElementById('catMenuTR3').style.display = 'none';
				} catch(err) { console.warn("[WARNING:59110] " + err.message); }

				var td, tr2, inp, inpO, imgClass, img;
				var trtd = document.createElement('td');
				var tb = document.createElement('table');
				var infDIV = document.createElement('div');
				tr.appendChild(trtd);
				trtd.appendChild(infDIV);
				trtd.appendChild(tb);
				infDIV.innerHTML = "(To delete a category,<br />simply delete the name)";
				infDIV.style.cssText = "text-align:center;font-style:italic;padding-bottom:20px;color:#DEB887;";
				var cat = $scope.data.categoryInformation;
				for (var ct = 0; ct < cat.length; ct++)
				{
					img = document.createElement('img');
					img.src = 'colorPicker2.png';
					img.style.cssText = 'width:20px;height:20px;';
					tr2 = document.createElement('tr');
					td = document.createElement('td');
					inp = document.createElement('input');
					inp.id = 'changeThisCategory_' + ct.toString() + '';
					inp.maxLength = 40;
					inp.style.color = cat[ct].fgc;
					inp.style.backgroundColor = cat[ct].bgc;
					inp.value = cat[ct].name;

					// Original value
					inpO = document.createElement('input');
					inpO.setAttribute("type", "hidden");
					inpO.id = 'hidden_changeThisCategory_' + ct.toString() + '';
					inpO.value = cat[ct].name;

					imgClass = 'JavaScript_ColorPicker{styleElement:';
					imgClass += "'changeThisCategory_" + ct.toString() + "',value:'";
					imgClass += cat[ct].bgc;
					imgClass += "'}";
					img.className = imgClass;

					tr2.appendChild(td);
					tb.appendChild(tr2);
					td.appendChild(inp);
					td.appendChild(inpO);
					td.appendChild(img);
				}
				$scope.initializeColorPicker();
				tr.style.display = "";
			}
			else
			{
				tr.style.display = "none";
				try {
					document.getElementById('catMenuTR1').style.display = '';
					document.getElementById('catMenuTR2').style.display = '';
					document.getElementById('catMenuTR3').style.display = '';
				} catch(err2) { console.warn("[WARNING:649296] " + err2.message); }
			}
		}
	}

	$scope.categoryMenu_Submit = function()
	{
		var inputs = document.getElementsByTagName('input');
		var a = [];
		var he, bad = false;
		var cb = document.getElementById('editExistingCategory_checkBox');

		if (cb && cb.checked)
		{
			for (var i = 0; i < inputs.length; i++)
			{
				if (inputs[i].id && inputs[i].id.indexOf('changeThisCategory_') == 0)
				{
					he = document.getElementById('hidden_changeThisCategory_'+inputs[i].id.split('_')[1]);
					if (he)
					{
						a.push({
							catN:inputs[i].value,
							catO:he.value,
							bgc:$scope.rgb2hex(inputs[i].style.backgroundColor),
							fgc:$scope.rgb2hex(inputs[i].style.color)
						});
					}
					else
					{
						bad = true;
						alert("There was an internal error submitting your category(ies).  Please report [ERROR:319]");
					}
				}
			}
		}
		else if (cb && !cb.checked)
		{
			var newCat = document.getElementById('new_category');
			var newCatColor = document.getElementById('new_categoryColor');
			if (newCat && newCat.value.toString().trim().length)
			{
				a.push({
					cat:newCat.value,
					bgc:$scope.rgb2hex(newCatColor.style.backgroundColor),
					fgc:$scope.rgb2hex(newCatColor.style.color)
				});

				try { document.getElementById('categoryMenuDIV').style.display = "none";} catch(err) { console.warn("[WARNING:536] " + err.message); }
				$scope.data.saveAndSubmit = 8;
				c_this.data.calUpdate = a;
				c_this.data.locationURL_CalVal = $scope.data.locationURL_CalVal;
				c_this.server.update().then(function(response) {
					if (c_this.data.serverUpdateResponse)
						alert(c_this.data.serverUpdateResponse + "     [ERROR:99551]");
					c_this.data.serverUpdateResponse = '';
					c_this.data.calUpdate = '';
					c_this.data.eventArray = '';
					console.info("c_this.server.update(): $scope.categoryMenu_Submit (new category)");
					$scope.categoryMenu_Cancel();
					$scope.build_new_eventCategory_selections('new_eventCategory');
				});
			}
			else
			{
				alert("Your new category name cannot be blank.");
				return;
			}
			return;
		}

		if (!bad)
		{
			try { document.getElementById('categoryMenuDIV').style.display = "none";} catch(err4) { console.warn("[WARNING:5376] " + err4.message); }
			$scope.data.saveAndSubmit = 7;
			c_this.data.calUpdate = a;
			c_this.data.locationURL_CalVal = $scope.data.locationURL_CalVal;
			c_this.server.update().then(function(response) {
				if (c_this.data.serverUpdateResponse)
					alert(c_this.data.serverUpdateResponse + "     [ERROR:9900]");
				c_this.data.serverUpdateResponse = '';
				c_this.data.calUpdate = '';
				c_this.data.eventArray = '';
				$scope.refreshCalendar();
				console.info("c_this.server.update(): $scope.categoryMenu_Submit (change categories)");
				$scope.categoryMenu_Cancel();
				$scope.build_new_eventCategory_selections('new_eventCategory');
			});
		}
	};

	$scope.categoryMenu_Cancel = function()
	{
		$scope.displayCategoryMenu = false;
		var tr = document.getElementById('editExistingCategory_TR');

		// Remove all tr children
		if (tr)
			while (tr.firstChild)
				tr.removeChild(tr.firstChild);

		try {
			document.getElementById('editExistingCategory_checkBox').checked = '';
			document.getElementById('catMenuTR1').style.display = '';
			document.getElementById('catMenuTR2').style.display = '';
			document.getElementById('catMenuTR3').style.display = '';
		} catch(g) {}

		try { document.getElementById('categoryMenuDIV').style.display = "none";} catch(err) { console.warn("[WARNING:57536] " + err.message); }
	};

	$scope.changeEditButton = function()
	{
		var b = document.getElementsByClassName('fc-edit_button-button');
		var h = document.getElementsByClassName('fc-hideInstructions_button-button');
		var c = document.getElementsByClassName('fc-category_button-button');
		if (b && b[0])
		{
			if ($scope.data.editButtonStatus == $scope.data.edibButton_STOP)
			{
				b[0].innerHTML = $scope.data.edibButton_STOP;
				b[0].style.cssText = 'background-image: none; background-color: rgb(255,0,0); color: rgb(255,255,255); border-color: rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.25); box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2), 0 1px 2px rgba(0, 0, 0, 0.05);';
				$scope.toggleTheHelpButton("on");
				$scope.toggleTheCategoryButton("on");
				console.info("Editing Started");
				document.getElementById('mainCalSelDIV').style.display = "none";
			}
			else if ($scope.data.editButtonStatus == $scope.data.editButton_EDIT)
			{
				b[0].innerHTML = $scope.data.editButton_EDIT;
				b[0].style.cssText = "";
				$scope.toggleTheHelpButton("off");
				$scope.toggleTheCategoryButton("off");
				$scope.removePopupEventOptions();
				console.info("Editing Stopped");
				document.getElementById('mainCalSelDIV').style.display = "";
			}
		}
		$scope.editingCalendar_updateDatabase();
		tOut = setTimeout(function(){ 
			$scope.setQuickAccessEventColor(); 
			$scope.setLeftColumnProperHeights(); 
			$scope.setLeftColumnProperWidths(); 
			if ($scope.data.howManyQuickAccessEvents <= 0)
				try { document.getElementById('btn_changeQuickAccessEventColor').style.display = "none";} catch(err7) { console.warn("[WARNING:4646456] " + err7.message); }
			else
				try { document.getElementById('btn_changeQuickAccessEventColor').style.display = "";} catch(err8) { console.warn("[WARNING:2234] " + err8.message); }
			clearTimeout(tOut); }, 100);
	};
	
	$scope.get_userSysID_from_QAE = function(val)
	{
		var retVal = '';
		var quickAccessEventDivs = document.getElementById('quickAccessEventColors').getElementsByTagName('div');
		if (quickAccessEventDivs)
		{
			for (t = 0; t < quickAccessEventDivs.length; t++)
			{
				if (quickAccessEventDivs[t].id && quickAccessEventDivs[t].id.indexOf('evtCC_') == 0)
				{
					if (quickAccessEventDivs[t].getAttribute('qaetitle') == val.title.trim())
					{
						retVal = quickAccessEventDivs[t].getAttribute('usersysid');
						break;
					}
				}
			}
		}
		return retVal;
	};

	$scope.saveThisEvent = function(eventID, isNew, removing, addingToQAE, addingFromQAE)
	{
		clearTimeout(tOut);
		var i, userNAME = '', userID = '';
		
		console.info("THIS: $scope.data.EventUser_sysID: " + $scope.data.EventUser_sysID);
		
		if ($scope.data.EventUser_sysID.toString().length == 32 && $scope.data.EventUser_name.toString().length)
		{
			userNAME = $scope.data.EventUser_name.toString();
			userID = $scope.data.EventUser_sysID.toString();
		}
		$scope.data.EventUser_name = '';
		$scope.data.EventUser_sysID = '';

		console.info("$scope.saveThisEvent(" + eventID + ", " + isNew + ", " + removing + ", " + addingToQAE + ", " + addingFromQAE + ") + typeof(eventID): " + typeof(eventID));

		if (removing && !isNew && typeof(eventID) == "string" && !addingFromQAE)
		{
			$scope.data.saveAndSubmit = 6;
			c_this.data.eventArray = eventID;
			c_this.data.locationURL_CalVal = $scope.data.locationURL_CalVal;
			c_this.server.update().then(function(response) {
				if (c_this.data.serverUpdateResponse)
					alert(c_this.data.serverUpdateResponse + "     [ERROR:8899]");
				c_this.data.serverUpdateResponse = '';
				c_this.data.calUpdate = '';
				c_this.data.eventArray = '';
				$scope.refreshCalendar();
				console.info("c_this.server.update(): $scope.saveAndSubmit (delete)");
			});
			return;
		}

		theEventArray = $("#calendar").fullCalendar( 'clientEvents');

		var ed = "null", ttitle = '';
		var ex;
		var exFound = false;

		if (!isNew && typeof(eventID) == "string" && !addingFromQAE)
			ed = [];
		else if (isNew && typeof(eventID) == "object" && !addingFromQAE)
			ed = eventID;
		else if (isNew && typeof(eventID) == "string" && addingFromQAE) // Quick Access event dragged onto calendar
		{
			ed = [];
			for (i = 0; i < theEventArray.length; i++)
			{
				if (theEventArray[i]._id.toString() == eventID)
				{
					if (userID.length == 0)
						userID = $scope.get_userSysID_from_QAE($("#calendar").fullCalendar( 'clientEvents')[i]);
					
					ex = $("#calendar").fullCalendar( 'clientEvents')[i];
					exFound = true;
					ttitle = ex.title;
					if (userNAME.length)
						ttitle = userNAME;
					ed.push({
						title:ttitle,
						start:ex.start,
						end:ex.end,
						backgroundColor:ex.backgroundColor,
						textColor:ex.textColor,
						category:'',
						userSysID:userID,
						id:eventID
					});
					break;
				}
			}
		}
		else
		{
			console.error('Unknown eventID: ' + eventID);
			return;
		}

		if (!isNew)
		{
			for (i = 0; i < theEventArray.length; i++)
			{
				if (theEventArray[i].id.toString() == eventID)
				{
					ttitle = theEventArray[i].title;
					if (userNAME.length)
						ttitle = userNAME;
					ed.push({
						title:ttitle,
						start:theEventArray[i].start,
						end:theEventArray[i].end,
						backgroundColor:theEventArray[i].backgroundColor,
						textColor:theEventArray[i].textColor,
						category:theEventArray[i].category,
						userSysID:userID,
						id:theEventArray[i].id
					});
					break;
				}
			}
		}

		// Update an existing event
		if (!isNew && eventID && ed.length)
		{
			$scope.data.saveAndSubmit = 1;
			c_this.data.eventArray = ed;
			c_this.data.locationURL_CalVal = $scope.data.locationURL_CalVal;
			c_this.server.update().then(function(response) {
				if (c_this.data.serverUpdateResponse)
					alert(c_this.data.serverUpdateResponse + "     [ERROR:320169]");
				c_this.data.serverUpdateResponse = '';
				c_this.data.calUpdate = '';
				c_this.data.eventArray = '';
				$scope.data.EventUser_name = '';
				$scope.data.EventUser_sysID = '';
				$scope.refreshCalendar();
				console.info("c_this.server.update(): $scope.saveAndSubmit (update)");
			});
		}
		else if (isNew && ed)
		{
			$scope.data.saveAndSubmit = 5;

			if (exFound && addingFromQAE)
				c_this.data.eventArray = ed[0];
			else if (!addingFromQAE)
				c_this.data.eventArray = ed;

			c_this.data.locationURL_CalVal = $scope.data.locationURL_CalVal;
			c_this.server.update().then(function(response) {
				if (c_this.data.serverUpdateResponse)
				{
					if (!exFound && !addingFromQAE)
						eventID.id = c_this.data.serverUpdateResponse;
					else if (exFound && addingFromQAE)
						ex.id = c_this.data.serverUpdateResponse;

					c_this.data.serverUpdateResponse = '';
					c_this.data.calUpdate = '';
					c_this.data.eventArray = '';
					$scope.data.newEvent_start = '';
					$scope.data.newEvent_end = '';
					$scope.data.EventUser_name = '';
					$scope.data.EventUser_sysID = '';

					// This *MUST* be handled here!, because we need to wait for the event id to come back from the record insert
					if (!exFound && !addingFromQAE)
						$('#calendar').fullCalendar('renderEvent', eventID, true);
					else if (ex && addingFromQAE)
						$('#calendar').fullCalendar('renderEvent', ex, true);

					$scope.refreshCalendar();
					console.info("c_this.server.update(): $scope.saveAndSubmit (insert)");

					if (addingToQAE)
						$scope.submitAddQuickAccessEvent(2, userID);
					else
						$scope.cancelNewEventAdd();
				}
				else
					alert("No Server Response for: $scope.saveThisEvent - [ERROR:5649]");
			});
		}
	};

	$scope.deleteThisQuickAccessEvent = function(val)
	{
		$scope.data.saveAndSubmit = 4;
		$scope.data.deleteQuickAccessEvent = val.toString().trim();
		c_this.data.locationURL_CalVal = $scope.data.locationURL_CalVal;
		c_this.server.update().then(function(response) {
			c_this.data.calUpdate = '';
			if (c_this.data.serverUpdateResponse)
				alert(c_this.data.serverUpdateResponse + "     [ERROR:14976]");
			c_this.data.serverUpdateResponse = '';
			$scope.data.deleteQuickAccessEvent = '';
			$scope.data.saveAndSubmit = 0;
			tOut = setTimeout(function(){ 
				$scope.setHowManyQuickAccessEvents();
				$scope.applyContextMenu(); 
				$scope.setLeftColumnProperHeights(); 
				$scope.setQuickAccessEventColor();
				$scope.initializeQuickAccessEventsDraggableProperties(); // We have to call $scope.initializeQuickAccessEventsDraggableProperties() here because the classes "ui-draggable" and "ui-draggable-handle" get removed after a quick access event gets added.
				if ($scope.data.howManyQuickAccessEvents <= 0)
					try { document.getElementById('btn_changeQuickAccessEventColor').style.display = "none";} catch(err7) { console.warn("[WARNING:233] " + err7.message); }
				else
					try { document.getElementById('btn_changeQuickAccessEventColor').style.display = "";} catch(err8) { console.warn("[WARNING:244] " + err8.message); }
				console.info("c_this.server.update(): $scope.deleteThisQuickAccessEvent");
				clearTimeout(tOut); }, 100);
		});
	};

	$scope.applyContextMenu_addEventListener = function(el)
	{
		if (el.addEventListener)
		{
			el.addEventListener('contextmenu', function(e) {
				if ($scope.data.calendarCanBeEdited && $scope.data.editButtonStatus == $scope.data.edibButton_STOP)
				{
					if (confirm("Delete the Quick Access Event:     " + e.target.innerHTML.trim() + " ?"))
					{
						$scope.deleteThisQuickAccessEvent(e.target.innerHTML);
					}
					e.preventDefault();
				}
			}, false);
		}
		else 
		{
			el.attachEvent('oncontextmenu', function() {
				if ($scope.data.calendarCanBeEdited && $scope.data.editButtonStatus == $scope.data.edibButton_STOP)
				{
					if (confirm("Delete the Quick Access Event:     " + e.target.innerHTML.trim() + " ?"))
					{
						$scope.deleteThisQuickAccessEvent(e.target.innerHTML);
					}
					window.event.returnValue = false;
				}
			});
		}
	};

	$scope.applyContextMenu = function()
	{
		try	{
			var divs = document.getElementById('external-events').getElementsByClassName('fc-event');
			for (var i = 0; i < divs.length; i++)
			{
				$scope.applyContextMenu_addEventListener(divs[i]);
			}
		} catch(err) { console.warn("**ERROR: " + err.message); }
	};

	$scope.changeQuickAccessEventColor = function()
	{
		$scope.initializeColorPicker(); // This is to re-apply the event listener to the color picker img
		try { document.getElementById('instructions').style.display = "none";} catch(err) { console.warn("**ERROR: " + err.message); }
		try { document.getElementById('btn_changeQuickAccessEventColor').style.display = "none";} catch(err2) { console.warn("**ERROR: " + err2.message); }
		try { document.getElementById('btn_addQuickAccessEvent').style.display = "none";} catch(err3) { console.warn("**ERROR: " + err3.message); }
		try { document.getElementById('addingQuickAccessEvent').style.display = 'none';} catch(err4) { console.warn("**ERROR: " + err4.message); }
		try { document.getElementById('quickAccessEventColors').style.display = '';} catch(err5) { console.warn("**ERROR: " + err5.message); }
	};

	$scope.colorCycle = function($event)
	{
		var e = $event.currentTarget;
		if (e)
		{
			// Only trigger if clicking on the event, not the color picker (prevent bubbling)
			if ($event.target.id.indexOf('evtCC_') != 0 && $event.target.id.indexOf('evtIMG_Holder_') != 0)
				return;

			var defaultRGB = $scope.hex2rgb($scope.data.defaultEventBackgroundColor);

			switch (e.style.backgroundColor)
			{
				case "":
					e.style.backgroundColor = "#00FF00"; // green
					e.style.color = "#000000"; // black
					break;
				case defaultRGB: // RGB value of HEX color $scope.data.defaultEventBackgroundColor
					e.style.backgroundColor = "#00FF00"; // green
					e.style.color = "#000000"; // black
					break;
				case "#00FF00": // rgb(0, 255, 0) (green)
					e.style.backgroundColor = "#0000FF"; // blue
					e.style.color = "#FFFFFF";
					break;
				case "rgb(0, 255, 0)": // #00FF00 (green)
					e.style.backgroundColor = "#0000FF"; // blue
					e.style.color = "#FFFFFF"; // white
					break;
				case "#0000FF": // blue
					e.style.backgroundColor = "#FF0000"; // red
					e.style.color = "#FFFFFF"; // white
					break;
				case "rgb(0, 0, 255)": // blue
					e.style.backgroundColor = "#FF0000"; // red
					e.style.color = "#FFFFFF"; // white
					break;
				case "#FF0000": // red
					e.style.backgroundColor = "#FFFF00"; // yellow
					e.style.color = "#000000"; // black
					break;
				case "rgb(255, 0, 0)": // red
					e.style.backgroundColor = "#FFFF00"; // yellow
					e.style.color = "#000000"; // black
					break;
				case "#FFFF00": // yellow
					e.style.backgroundColor = "";
					e.style.color = "#FFFFFF"; // white
					break;
				case "rgb(255, 255, 0)": // yellow
					e.style.backgroundColor = "";
					e.style.color = "#FFFFFF"; // white
					break;
				default:
					e.style.backgroundColor = "";
					e.style.color = "#FFFFFF"; // white
			}

			// Now set the color picker img class with this new information
			try {
				var id = e.id.split('_')[1];
				var el = document.getElementById('evtIMG_' + id);
				if (el)
				{
					el.className = '';
					var rgb = $scope.rgb2hex(e.style.backgroundColor, 1);
					el.classList.add("JavaScript_ColorPicker{styleElement:'evtCC_" + id + "',value:'" + rgb + "'}");
					el.textContent = rgb;

					// This image has event handlers attached to it that can't get removed, so we need to:
					//    1. Copy the outerHTML of this img element into a temp variable
					//    2. Capture the img element's parent into a temp varialbe
					//    3. Delete the img element
					//    4. Create a new img element
					//    5. Stick this new element into the old img parent
					//    6. Copy back in the outerHTML of the old img element
					//    7. Finally, when the DOM is ready, call jsc.init() which re-applies the jscolor event handlers
					var newEL = document.createElement('img');
					var el_tmp_html = el.outerHTML;
					var par = el.parentNode;
					el.parentNode.removeChild(el);
					par.appendChild(newEL);
					newEL.outerHTML = el_tmp_html;
					newEL.textContent = rgb;
					newEL.classList.add("JavaScript_ColorPicker{styleElement:'evtCC_" + id + "',value:'" + rgb + "'}");
					$(document).ready(function() { jsc.init(); });
				}
			} catch(err) { console.warn("**ERROR: " + err.message); }
		}
	};

	$scope.editEventColor_processHashValue = function($event)
	{
		var e = $event.currentTarget;
		if (e)
		{
			var i = e.id.split('_')[1];
			var te = document.getElementById('evtINPUTHASH_' + (i.toString()) + '');
			if (te)
			{
				if (te.style.display == '')
					te.style.display = 'none';
				else
					te.style.display = '';
			}
		}
	};

	$scope.saveColorChange = function()
	{
		var colors = [];
		var quickAccessEventDivs;
		var t = 0;

		try
		{
			quickAccessEventDivs = document.getElementById('quickAccessEventColors').getElementsByTagName('div');
			if (quickAccessEventDivs)
			{
				for (t = 0; t < quickAccessEventDivs.length; t++)
				{
					if (quickAccessEventDivs[t].id && quickAccessEventDivs[t].id.indexOf('evtCC_') == 0)
					{
						colors.push({
							quickAccessEvent:quickAccessEventDivs[t].getAttribute('qaetitle'),
							bgc:quickAccessEventDivs[t].style.backgroundColor,
							fgc:quickAccessEventDivs[t].style.color,
							user:quickAccessEventDivs[t].getAttribute('usersysid')
						});
					}
				}
			}

			$scope.data.saveAndSubmit = 2;
			c_this.data.calUpdate = colors;
			c_this.data.locationURL_CalVal = $scope.data.locationURL_CalVal;
			c_this.server.update().then(function(response) {
				c_this.data.calUpdate = '';
				if (c_this.data.serverUpdateResponse)
					alert(c_this.data.serverUpdateResponse + "     [ERROR:124181]");
				c_this.data.serverUpdateResponse = '';

				tOut = setTimeout(function(){ 
					$scope.setHowManyQuickAccessEvents();
					$scope.applyContextMenu(); 
					$scope.refreshCalendar();
					if ($scope.displayInstructions)
						try { document.getElementById('instructions').style.display = ""; } catch(err1) { console.warn("[WARNING:986] " + err1.message); }
					if ($scope.displayCategoryMenu)
						try { document.getElementById('categoryMenuDIV').style.display = ""; } catch(err5) { console.warn("[WARNING:985] " + err5.message); }
					if ($scope.data.howManyQuickAccessEvents > 0)
						try { document.getElementById('btn_changeQuickAccessEventColor').style.display = ""; } catch(err4) { console.warn("[WARNING:98] " + err4.message); }
					try { document.getElementById('btn_addQuickAccessEvent').style.display = ""; } catch(err2) { console.warn("[WARNING:94] " + err2.message); }
					try { document.getElementById('quickAccessEventColors').style.display = 'none'; } catch(err3) { console.warn("[WARNING:955] " + err3.message); }
					$scope.setQuickAccessEventColor();

					// We have to call $scope.initializeQuickAccessEventsDraggableProperties() here because 
					// the classes "ui-draggable" and "ui-draggable-handle" get removed after a quick access event gets added.
					$scope.initializeQuickAccessEventsDraggableProperties(); 

					console.info("c_this.server.update(): $scope.saveColorChange");
					clearTimeout(tOut); }, 100); 
			});
		} catch(err) { console.warn("[WARNING:660577] " + err.message); }
	};

	$scope.cancelColorChange = function()
	{
		$scope.setQuickAccessEventColor();
		if ($scope.displayInstructions)
			try { document.getElementById('instructions').style.display = "";} catch(err) { console.warn("[WARNING:989619] " + err.message); }
		if ($scope.displayCategoryMenu)
			try { document.getElementById('categoryMenuDIV').style.display = "";} catch(err7) { console.warn("[WARNING:9789619] " + err7.message); }
		try { if ($scope.data.howManyQuickAccessEvents > 0) document.getElementById('btn_changeQuickAccessEventColor').style.display = "";} catch(err2) { console.warn("[WARNING:513340] " + err2.message); }
		try { document.getElementById('btn_addQuickAccessEvent').style.display = "";} catch(err3) { console.warn("[WARNING:902546] " + err3.message); }
		try { document.getElementById('addingQuickAccessEvent').style.display = 'none';} catch(err4) { console.warn("[WARNING:959972] " + err4.message); }
		try { document.getElementById('quickAccessEventColors').style.display = 'none';} catch(err5) { console.warn("[WARNING:390509] " + err5.message); }
		try { document.getElementById('quickAccessEventToAdd').value = '';} catch(err6) { console.warn("[WARNING:526779] " + err6.message); }
	};

	$scope.setQuickAccessEventColor = function()
	{
		var t = 0, e = 0;
		var quickAccessEventDivs;
		var cAry = $scope.data.quickAccessEvents;
		try {
			quickAccessEventDivs = document.getElementById('external-events').getElementsByTagName('div');
			if (quickAccessEventDivs)
			{
				for (t = 0; t < quickAccessEventDivs.length; t++)
				{
					for (e = 0; e < cAry.length; e++)
					{
						if (quickAccessEventDivs[t].getAttribute('qaetitle') == cAry[e].title.trim())
						{
							quickAccessEventDivs[t].style.backgroundColor = cAry[e].bgc;
							quickAccessEventDivs[t].style.color = cAry[e].fgc;
						}
					}
				}
			}
		} catch(err) { console.warn("[WARNING:724077] " + err.message); }

		try	{
			quickAccessEventDivs = document.getElementById('quickAccessEventColors').getElementsByTagName('div');
			if (quickAccessEventDivs)
			{
				for (t = 0; t < quickAccessEventDivs.length; t++)
				{
					for (e = 0; e < cAry.length; e++)
					{
						if (quickAccessEventDivs[t].getAttribute('qaetitle') == cAry[e].title.trim())
						{
							if (cAry[e].bgc != '')
								quickAccessEventDivs[t].style.backgroundColor = cAry[e].bgc;
							if (cAry[e].fgc != '')
								quickAccessEventDivs[t].style.color = cAry[e].fgc;
						}
					}
				}
			}
		} catch(err2) { console.warn("[WARNING:970861] " + err2.message); }
	};

	$scope.deleteThisEvent = function(popup, calEvent)
	{
		if (confirm("Delete this entry?"))
		{
			$scope.saveThisEvent(calEvent.id, false, true, false, false);
			$('#calendar').fullCalendar('removeEvents', function (event) { return event == calEvent; });
			$scope.removePopupEventOptions();
			$scope.data.EventUser_name = '';
			$scope.data.EventUser_sysID = '';
		}
	};

	$scope.changeEventInformation = function(colorButton, popup, calEvent)
	{
		try {
			var catSel = document.getElementById('edit_eventCategory');
			if (catSel)
			{
				if (catSel.options[catSel.options.selectedIndex].textContent == $scope.defaultCategorySelectOption)
					calEvent.category = '';
				else
					calEvent.category = catSel.options[catSel.options.selectedIndex].textContent;
			}
		} catch(err3) { console.warn("[WARNING:94232] " + err3.message); }

		if (colorButton.innerHTML == "Default")
		{
			calEvent.backgroundColor = $scope.hex2rgb($scope.data.defaultEventBackgroundColor);
			calEvent.textColor = '';
		}
		else
		{
			try
			{
				var cp = colorButton;
				var tf = document.getElementById('input_u_selected_event_hex_color');

				if (tf.value.indexOf('#') != 0)
					tf.value = '#' + tf.value + '';

				if (tf.value.length == 7)
				{
					var isProperHex = /^#[0-9A-F]{6}$/i.test(tf.value);
					if (isProperHex)
					{
						colorButton.value = tf.value;
						colorButton.dispatchEvent(new Event('keyup'));
					}
					else
					{
						alert("Your color value is not valid.");
						return;
					}
				}
			} catch(err) { console.warn("[WARNING:463758] " + err.message); }

			try {
				var nName = '';
				
				if (document.getElementById('change_event_name_userCB').checked != true)
					nName = document.getElementById('input_u_new_title').value.toString().trim();
				else if (document.getElementById('change_event_name_userCB').checked == true && $scope.data.EventUser_sysID.toString().length == 32 && $scope.data.EventUser_name.toString().length)
					nName = $scope.data.EventUser_name.toString().trim();

				if (!nName.length)
				{
					alert("The Event Name cannot be blank.");
					document.getElementById('input_u_new_title').value = calEvent.title;
					document.getElementById('input_u_new_title').focus();
					return;
				}
				
				if ($scope.data.EventUser_sysID.toString().length == 32 && $scope.data.EventUser_name.toString().length)
				{
					if (nName != $scope.data.EventUser_name.toString().trim())
					{
						$scope.data.EventUser_name = '';
						$scope.data.EventUser_sysID = '';
					}
				}
				
				calEvent.title = nName;
				calEvent.backgroundColor = colorButton.style.backgroundColor;
				calEvent.textColor = colorButton.style.color;
			} catch(err2) { console.warn("[WARNING:942] " + err2.message); }
		}
		$scope.removePopupEventOptions();
		$scope.saveThisEvent(calEvent.id, false, false, false, false);
	};

	$scope.removePopupEventOptions = function()
	{
		var popup = document.getElementById('myPopup');
		try {
			while (popup.firstChild)
			{
				popup.removeChild(popup.firstChild);
			}
			popup.classList.remove("show");
		} catch(err) { console.warn("[WARNING:410788] " + err.message); }
	};

	$scope.rgb2hex = function(rgb, flag)
	{
		var retVal = $scope.data.defaultEventBackgroundColor;
		if (flag != 1)
			retVal = '';
		if (rgb && rgb.length)
		{
			rgb = rgb.match(/^rgba?[\s+]?\([\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?/i);

			if (rgb && rgb.length === 4)
			{
				retVal = "#" +
					("0" + parseInt(rgb[1],10).toString(16).toUpperCase()).slice(-2) +
					("0" + parseInt(rgb[2],10).toString(16).toUpperCase()).slice(-2) +
					("0" + parseInt(rgb[3],10).toString(16).toUpperCase()).slice(-2);
			}
		}
		return retVal;
	};

	$scope.hex2rgb = function(hex)
	{
		// Expand shorthand form (e.g. "03F") to full form (e.g. "0033FF")
		var shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
		hex = hex.replace(shorthandRegex, function(m, r, g, b) {
			return r + r + g + g + b + b;
		});

		var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);

		if (result)
			return 'rgb(' + parseInt(result[1], 16) + ', ' + parseInt(result[2], 16) + ', ' + parseInt(result[3], 16) + ')';

		return '';
	};

	$scope.calFullScreen = function(flag)
	{
		if ($scope.data.editButtonStatus == $scope.data.editButton_EDIT)
		{
			if ($scope.data.viewRatio == 'standard')
			{
				document.getElementById('external-events').style.display = 'none';
				document.getElementById('mainCalSelDIV').style.display = 'none';
				document.getElementsByClassName('fc-toolbar')[0].style.display = 'none';
				document.getElementById('calTitle').style.paddingLeft = '';
				if (flag == 1)
				{
					document.getElementById('calTitle').style.display = 'none';
					document.getElementsByTagName('header')[0].style.display = 'none';
				}
				document.getElementById('masterDIV').classList.add('zoomIN');
				$scope.data.viewRatio = 'full';
			}
			else
			{
				document.getElementById('external-events').style.display = '';
				document.getElementById('mainCalSelDIV').style.display = '';
				document.getElementsByClassName('fc-toolbar')[0].style.display = '';
				document.getElementById('calTitle').style.display = '';
				document.getElementById('calTitle').style.paddingLeft = ''+$scope.data.titlePaddingLeft+'px';
				document.getElementsByTagName('header')[0].style.display = '';
				document.getElementById('masterDIV').classList.remove('zoomIN');
				$scope.data.viewRatio = 'standard';
			}
		}
		else
		{
			alert("You must exit edit mode first.");
		}
	};

	$scope.popupEventOptions = function(calEvent, jsEvent, view)
	{
		// First, delete any elements in the popup div
		$scope.removePopupEventOptions();
		$scope.data.EventUser_name = '';
		$scope.data.EventUser_sysID = '';

		if ($scope.data.calendarCanBeEdited && $scope.data.editButtonStatus == $scope.data.edibButton_STOP)
		{
			// If holding the ALT key down, simply delete event with no confirmation
			if (ALT_key_down)
			{
				var eid = calEvent.id;
				$scope.saveThisEvent(eid, false, true, false, false);
				$('#calendar').fullCalendar('removeEvents', function (event) { return event == calEvent; });
				$scope.removePopupEventOptions();
				return;
			}

			var popupHeading = 'Event Options for:';
			popupHeading += '<div style="color: rgb(255,255,0);font-size: larger;">';
			popupHeading += calEvent.title;
			popupHeading += '</div>';

			var popup = document.getElementById('myPopup');
			popup.innerHTML = popupHeading;
			popup.classList.add("show");

			// Div containers for each button
			var div_db = document.createElement('div');
			div_db.style.cssText = "margin-top: 20px;";
			var div_ce = document.createElement('div');
			div_ce.style.cssText = "margin-top: 20px;font-weight: bold;text-decoration: underline;margin-bottom: 10px;";
			var div_cb = document.createElement('div');
			div_cb.style.cssText = "margin-top: 20px;";
			var div_cb_Default = document.createElement('div');
			div_cb_Default.style.cssText = "margin-top: 5px;";
			var div_colorPicker = document.createElement('div');
			div_colorPicker.style.cssText = "margin-top: 5px;";
			var div_hexColor = document.createElement('div');
			div_hexColor.style.cssText = "margin-top: 5px;";
			var div_rename = document.createElement('div');
			div_rename.style.cssText = "margin-top: 20px;";
			div_rename.innerHTML = "Rename Event";
			var div_or = document.createElement('div');
			div_or.innerHTML = 'or';
			div_or.style.cssText = "margin-top: 10px;font-style: italic;";
			var div_color_picker_title = document.createElement('div');
			div_color_picker_title.innerHTML = 'Color Picker';
			div_color_picker_title.style.cssText = "margin-top: 15px;";
			var div_manual_input_title = document.createElement('div');
			div_manual_input_title.innerHTML = 'Manual Input';
			var div_category = document.createElement('div');
			div_category.style.cssText = "margin-top: 20px;font-weight: bold;text-decoration: underline;margin-bottom: 10px;";
			var div_userCB = document.createElement('div');
			var div_userTF = document.createElement('div');
			div_userTF.id = "div_userTF";
			div_userTF.style.display = "none";

			var div_colorOptions = document.createElement('div');
			div_colorOptions.style.cssText = 'background: rgba(160, 160, 160, 0.25);';

			var evtTitle = calEvent.title;

			if (calEvent.category.toString().length)
				evtTitle = calEvent.title.replace('['+calEvent.category+'] ', '');

			var renameTF = document.createElement('input');
			renameTF.maxLength = 40;
			renameTF.value = evtTitle;
			renameTF.id = 'input_u_new_title';
			renameTF.style.color = '#000000';
			renameTF.style.width = "125px";
			
			var userCB = document.createElement('input');
			userCB.setAttribute("type", "checkbox");
			userCB.style.cssText = "zoom: 1.5; vertical-align: bottom;";
			userCB.id = "change_event_name_userCB";
			userCB.onclick = function(){
				try{ 
					if (this.checked)
					{
						document.getElementById('div_userTF').style.display = "";
						document.getElementById('input_u_new_title').style.display = "none";
					}else{
						document.getElementById('div_userTF').style.display = "none";
						document.getElementById('input_u_new_title').style.display = "";
					}
				}catch(e){console.warn(e.message);}};
			div_userCB.textContent = "User ";
			div_userCB.appendChild(userCB);
			
			var colorPickerTF = document.createElement('input');
			colorPickerTF.style.width = "100px";
			colorPickerTF.style.height = "35px";
			colorPickerTF.style.textAlign = "center";
			colorPickerTF.style.cursor = "pointer";
			colorPickerTF.disabled = true;
			colorPickerTF.id = 'input_u_selected_event_color';
			colorPickerTF.className = "JavaScript_ColorPicker";
			colorPickerTF.value = calEvent.backgroundColor;

			div_colorPicker.appendChild(div_color_picker_title);
			div_colorPicker.appendChild(colorPickerTF);

			var hexColorTF = document.createElement('input');
			hexColorTF.style.width = "100px";
			hexColorTF.style.color = '#000000';
			hexColorTF.style.textAlign = "center";
			hexColorTF.maxLength = 7;
			hexColorTF.id = 'input_u_selected_event_hex_color';
			//hexColorTF.value = $scope.rgb2hex(calEvent.backgroundColor);
			hexColorTF.value = '';
			hexColorTF.placeholder = '#HEX Value';
			hexColorTF.onfocus = function(){this.placeholder = '';};
			hexColorTF.onblur = function(){if (!this.value) this.placeholder = '#HEX Value';};

			div_hexColor.appendChild(div_manual_input_title);
			div_hexColor.appendChild(hexColorTF);

			// Delete button
			var db = document.createElement('button');
			db.onclick = function(){$scope.deleteThisEvent(popup, calEvent)};
			db.innerHTML = "Delete Event";
			db.style.cssText = "color: rgb(255,0,0);font-weight:bold;";

			// Cancel button
			var cb = document.createElement('button');
			cb.onclick = function(){$scope.removePopupEventOptions();};
			cb.innerHTML = "Cancel";
			cb.style.cssText = "color: rgb(0,0,0);";

			// Save button
			var sb = document.createElement('button');
			sb.onclick = function(){$scope.changeEventInformation(colorPickerTF, popup, calEvent)};
			sb.innerHTML = "Save";
			sb.style.cssText = "color: rgb(0,0,0);";

			var defaultRGB = $scope.hex2rgb($scope.data.defaultEventBackgroundColor);
			// Color buttons
			var cb_Default = document.createElement('button');
			cb_Default.onclick = function(){$scope.changeEventInformation(cb_Default, popup, calEvent)};
			cb_Default.innerHTML = "Default";
			cb_Default.style.cssText = "background-color: " + defaultRGB + ";width: 100px;";

			// Category select
			var categoryDIV = document.createElement('div');
			var categorySELECT = document.createElement('select');
			categorySELECT.id = 'edit_eventCategory';
			categorySELECT.style.cssText = "background-color:#FFFFFF; color: #000000;";
			categoryDIV.appendChild(categorySELECT);

			div_db.appendChild(db); // This must go first
			div_rename.appendChild(renameTF);
			div_cb_Default.appendChild(cb_Default);
			div_cb.appendChild(sb);
			div_cb.appendChild(cb); // This must go last

			div_colorOptions.appendChild(div_colorPicker);
			div_colorOptions.appendChild(div_or);
			div_colorOptions.appendChild(div_hexColor);

			popup.appendChild(div_db); // This must go first
			popup.appendChild(div_rename);
			popup.appendChild(div_userTF);
			popup.appendChild(div_userCB);
			popup.appendChild(div_ce);
			popup.appendChild(div_cb_Default);
			popup.appendChild(div_colorOptions);
			popup.appendChild(div_category);
			popup.appendChild(categoryDIV);
			popup.appendChild(div_cb); // This must go last

			div_ce.innerHTML = "Choose Event Color";
			div_category.innerHTML = "Category<br>(you will lose any color options you chose above)";

			// Category Select Handling
			$scope.build_new_eventCategory_selections('edit_eventCategory');
			if (calEvent.category.toString().length)
			{
				for (var o = 0; o < categorySELECT.options.length; o++)
				{
					if (categorySELECT.options[o].textContent == calEvent.category)
					{
						categorySELECT.options[o].selected = true;
						categorySELECT.options[categorySELECT.options.selectedIndex].setAttribute("selected", "selected");
						categorySELECT.style.backgroundColor = categorySELECT.options[categorySELECT.options.selectedIndex].style.backgroundColor;
						categorySELECT.style.color = categorySELECT.options[categorySELECT.options.selectedIndex].style.color;
						break;
					}
				}
			}

			popup.onblur = function(){$scope.removePopupEventOptions();};
			popup.focus();
			$scope.initializeColorPicker();
			
			var nn = document.getElementById('new_eventName');
			var nen = '';
			if (nn)
				nen = nn.value.toString().trim();
			
			$scope.build_recordPicker_for_user_table(calEvent);
		}
	};

	$scope.submitAddQuickAccessEvent = function(comingFrom, userID)
	{
		var senderID = 'quickAccessEventToAdd';
		if (comingFrom == 2)
			senderID = 'new_eventName';
		//else if (comingFrom == 3)
		//	senderID = $scope.data.EventUser_name;
		
		var e = document.getElementById(senderID);
		if (e)
		{
			if (e.value.trim())
			{
				$scope.data.saveAndSubmit = 3;
				$scope.data.qae_userID = userID;
				$scope.data.addQuickAccessEvent = e.value.trim();
				c_this.data.locationURL_CalVal = $scope.data.locationURL_CalVal;
				c_this.server.update().then(function(response) {
					c_this.data.calUpdate = '';
					if (c_this.data.serverUpdateResponse)
						alert(c_this.data.serverUpdateResponse + "     [ERROR:175734]");
					c_this.data.serverUpdateResponse = '';
					$scope.data.addQuickAccessEvent = '';
					$scope.data.qae_userID = '';
					$scope.data.saveAndSubmit = 0;
					$scope.cancelNewEventAdd();

					tOut = setTimeout(function(){ 
						$scope.setHowManyQuickAccessEvents();
						$scope.applyContextMenu(); 
						$scope.setLeftColumnProperHeights(); 
						$scope.setQuickAccessEventColor();
						$scope.initializeQuickAccessEventsDraggableProperties(); // We have to call $scope.initializeQuickAccessEventsDraggableProperties() here because the classes "ui-draggable" and "ui-draggable-handle" get removed after a quick access event gets added.
						if ($scope.data.howManyQuickAccessEvents <= 0)
							try { document.getElementById('btn_changeQuickAccessEventColor').style.display = "none";} catch(err7) { console.warn("[WARNING:23] " + err7.message); }
						else
							try { document.getElementById('btn_changeQuickAccessEventColor').style.display = "";} catch(err8) { console.warn("[WARNING:24] " + err8.message); }
						console.info("c_this.server.update(): $scope.submitAddQuickAccessEvent");
						clearTimeout(tOut); }, 100); 
					if ($scope.displayInstructions)
						try { document.getElementById('instructions').style.display = "";} catch(err) { console.warn("[WARNING:3838] " + err.message); }
					if ($scope.displayCategoryMenu)
						try { document.getElementById('categoryMenuDIV').style.display = "";} catch(err7) { console.warn("[WARNING:38358] " + err7.message); }
					try { if ($scope.data.howManyQuickAccessEvents > 0) document.getElementById('btn_changeQuickAccessEventColor').style.display = "";} catch(err2) { console.warn("[WARNING:806424] " + err2.message); }
					try { document.getElementById('btn_addQuickAccessEvent').style.display = "";} catch(err3) { console.warn("[WARNING:817623] " + err3.message); }
					try { document.getElementById('quickAccessEventColors').style.display = 'none';} catch(err4) { console.warn("[WARNING:427572] " + err4.message); }
					try { document.getElementById('addingQuickAccessEvent').style.display = 'none';} catch(err5) { console.warn("[WARNING:497644] " + err5.message); }
					try { document.getElementById('quickAccessEventToAdd').value = '';} catch(err6) { console.warn("[WARNING:278919] " + err6.message); }
				});
			}
		}
	};

	$scope.addQuickAccessEvent = function()
	{
		try { document.getElementById('instructions').style.display = "none"; } catch(err) { console.warn("[WARNING:698955] " + err.message); }
		try { document.getElementById('btn_changeQuickAccessEventColor').style.display = "none"; } catch(err2) { console.warn("[WARNING:337299] " + err2.message); }
		try { document.getElementById('btn_addQuickAccessEvent').style.display = "none"; } catch(err3) { console.warn("[WARNING:530140] " + err3.message); }
		try { document.getElementById('quickAccessEventColors').style.display = 'none'; } catch(err4) { console.warn("[WARNING:28136] " + err4.message); }
		try { document.getElementById('addingQuickAccessEvent').style.display = ''; } catch(err5) { console.warn("[WARNING:283035] " + err5.message); }
		try { document.getElementById('quickAccessEventToAdd').focus(); } catch(err6) { console.warn("[WARNING:34870] " + err6.message); }
	};

	$scope.setLeftColumnProperHeights = function()
	{
		try	{
			var t = document.getElementById('external-events').getElementsByTagName('div');
			var howManyQuickAccessEvents = t.length;
			var baseMarginTop = 25;
			var quickAccessEventColors_marginTop = (baseMarginTop + (howManyQuickAccessEvents * 35) + 20);
			var instructions_marginTop = (quickAccessEventColors_marginTop + 30);

			try { document.getElementById('quickAccessEventColors').style.marginTop = '' + quickAccessEventColors_marginTop + 'px'; } catch(err2) { console.warn("[WARNING:833121] " + err2.message); }
			try { document.getElementById('addingQuickAccessEvent').style.marginTop = '' + quickAccessEventColors_marginTop + 'px'; } catch(err3) { console.warn("[WARNING:884796] " + err3.message); }
			try { document.getElementById('instructions').style.marginTop = '' + instructions_marginTop + 'px'; } catch(err4) { console.warn("[WARNING:620399: " + err4.message); }
		} catch(err) { console.warn("**ERROR: " + err.message); }
	};

	$scope.setLeftColumnProperWidths = function()
	{
		try	{
			var w = document.getElementById('external-events').offsetWidth; // http://stackoverflow.com/questions/294250/how-do-i-retrieve-an-html-elements-actual-width-and-height
			try { document.getElementById('quickAccessEventColors').style.width = w + 'px'; } catch(err2) { console.warn("[WARNING:81661] " + err2.message); }
			try { document.getElementById('addingQuickAccessEvent').style.width = w + 'px'; } catch(err3) { console.warn("[WARNING:178966] " + err3.message); }
			try { document.getElementById('instructions').style.width = w + 'px'; } catch(err4) { console.warn("[WARNING:874781: " + err4.message); }
			$scope.setWidth_CalList();
		} catch(err) { console.warn("[WARNING:14533: " + err.message); }
	};

	$scope.clearColorTimer = function()
	{
		clearTimeout(colorTIMEOUT);
	};

	$scope.initializeColorPicker = function()
	{
		colorTIMEOUT = setTimeout(function(){ 
			jsc.jscolor.lookupClass = 'JavaScript_ColorPicker';
			jsc.jscolor.installByClassName = function (className) {
				var inputElms = document.getElementsByTagName('input');
				jsc.tryInstallOnElements(inputElms, className);

				var inputElms2 = document.getElementsByTagName('img');
				jsc.tryInstallOnElements(inputElms2, className);
			};
			jsc.register();
			$scope.clearColorTimer();
		}, 50);
	};

	$scope.build_new_eventCategory_selections = function(val)
	{
		try {
			var e = document.getElementById(val);
			var cat = $scope.data.categoryInformation;
			var ih = '<option style="background-color:#FFFFFF; color: #000000;" value="">' + $scope.defaultCategorySelectOption + '</option>';
			for (var ct = 0; ct < cat.length; ct++)
			{
				ih += '<option value="' +  cat[ct].name;
				ih += '" style="background-color:' + cat[ct].bgc;
				ih += '; color:' + cat[ct].fgc;
				ih += ';">';
				ih += cat[ct].name;
				ih += '</option>';
			}
			if (e)
			{
				e.innerHTML = ih;

				// Add onchange function to change the color when selected
				e.onchange = function() {
					var	bg_color = e.options[e.selectedIndex].style.backgroundColor;
					var	fg_color = e.options[e.selectedIndex].style.color;
					e.style.backgroundColor = bg_color;
					e.style.color = fg_color;
					e.blur(); // This just unselects the select list without having to click somewhere else on the page
				}
			}
		} catch(err) { console.warn("[WARNING:2677: " + err.message); }
	};

	$scope.initializeQuickAccessEventsDraggableProperties = function()
	{
		// Initialize the external events
		//-----------------------------------------------------------------
		$('#external-events .fc-event').each(function() {
			// store data so the calendar knows to render an event upon drop
			$(this).data('event', {
				title: $.trim($(this).text()), // use the element's text as the event title
				stick: true // maintain when user navigates (see docs on the renderEvent method)
			});

			// make the event draggable using jQuery UI
			$(this).draggable({
				zIndex: 999,
				revert: true,      // will cause the event to go back to its
				revertDuration: 0  //  original position after the drag
			});
		});
	};

	$scope.createNewEvent = function(start, end)
	{
		try{
			if (document.getElementById('addEventDiv').style.display == '')
			{
				$scope.data.newEventTriggered = false;
				$scope.cancelNewEventAdd();
				return;
			}
		} catch(err){ console.warn(err.message); }

		try{
			$scope.EventUser = {  
				displayValue: '',  
				value: '',  
				name: 'EventUser'  
			};
			$scope.data.EventUser_sysID = '';
			$scope.data.EventUser_name = '';
			document.getElementById('addEventDiv').style.display = '';
			document.getElementById('calendar').style.opacity = 0.3;
			document.getElementById('leftCOLUMN').style.opacity = 0.3;
			document.getElementById('new_eventName').focus();
			var d = start.toString();
			var dt = d.split(' ')[0]+' '+d.split(' ')[1]+' '+d.split(' ')[2]+' '+d.split(' ')[3];
			$scope.data.createNewEventDateDisplay = dt;
			document.getElementById('dateNum').innerHTML = $scope.data.createNewEventDateDisplay;
			document.getElementById('new_eventColor').style.backgroundColor = $scope.data.defaultEventBackgroundColor;
			document.getElementById('new_eventColor').style.color = '#fff';
			$scope.data.newEvent_start = start;
			$scope.data.newEvent_end = end;

			// Hide anything else that might be showing
			$scope.cancelColorChange();
			$scope.removePopupEventOptions();

			$scope.data.newEventTriggered = true;
			$scope.createNewEvent_evtListener();

		} catch(er){ console.warn(er.message); }
	};

	$scope.removeNewEvent_evtListener = function()
	{
		try{
			document.getElementById('masterBodyDiv').onclick = null;
		} catch(er){ console.warn(er.message); }
	};

	$scope.createNewEvent_evtListener = function()
	{
		try{
			document.getElementById('masterBodyDiv').onclick = function(e) {

				if ($scope.data.newEventTriggered)
				{
					$scope.data.newEventTriggered = false;
					return;
				}

				if(e.target != document.getElementById('addEventDivTABLE')) {
					var dFound = false;
					var a = e.target;
					var els = [];
					while (a) {
						els.unshift(a);
						a = a.parentNode;
						if (a && a.id && a.id == 'addEventDiv')
							dFound = true;
					}
					if (!dFound)
					{
						$scope.cancelNewEventAdd();
					}
					else
					{
						document.getElementById('dateNum').innerHTML = $scope.data.createNewEventDateDisplay;
					}
				} else {
					console.warn("$scope.createNewEvent_evtListener hit an else");
				}
			}
		} catch(er){ console.warn(er.message); }
	};

	$scope.cancelNewEventAdd = function()
	{
		document.getElementById('addEventDiv').style.display = 'none';
		document.getElementById('calendar').style.opacity = 1;
		document.getElementById('leftCOLUMN').style.opacity = 1;
		document.getElementById('newEvent_pickUser').style.display = 'none';
		document.getElementById('newEvent_customName').style.display = '';

		// Clear the values
		document.getElementById('dateNum').innerHTM = '';
		document.getElementById('new_eventName').value = '';
		document.getElementById('new_addToQA').checked = '';
		document.getElementById('newEvent_pickEvent_CB').checked = '';
		$scope.EventUser = {  
			displayValue: '',  
			value: '',  
			name: 'EventUser'  
		};
		$scope.data.EventUser_sysID = '';
		$scope.data.EventUser_name = '';
		$scope.removeNewEvent_evtListener();
	};

	$scope.submitNewEvent = function()
	{
		var qae = document.getElementById('new_addToQA').checked;
		var bgc = $scope.rgb2hex(document.getElementById('new_eventColor').style.backgroundColor);
		var fgc = $scope.rgb2hex(document.getElementById('new_eventColor').style.color);
		var catSel = document.getElementById('new_eventCategory');
		var eventData;
		var userNAME = '', userID = '';
		
		if ($scope.data.EventUser_sysID.toString().length == 32 && $scope.data.EventUser_name.toString().length)
		{
			userNAME = $scope.data.EventUser_name.toString();
			userID = $scope.data.EventUser_sysID.toString();
		}
		
		var title = document.getElementById('new_eventName').value;
		
		if (title && title.trim().length > 0) 
		{
			var cat = catSel.options[catSel.options.selectedIndex].textContent;
			if (cat == $scope.defaultCategorySelectOption)
				cat = '';

			eventData = {
				title: title,
				start: $scope.data.newEvent_start,
				end: $scope.data.newEvent_end,
				editable: true,
				resourceEditable: true,
				backgroundColor: bgc,
				textColor: fgc,
				category: cat,
				userSysID:userID,
				id:''
			};
			$scope.saveThisEvent(eventData, true, false, qae ? true:false, false);
		}
		else
			alert("Event Name cannot be blank.")
		};

	$scope.initializeCalendar = function()
	{
		clearTimeout(tOut);
		$scope.initializeQuickAccessEventsDraggableProperties();

		var today = new Date();
		var dd = today.getDate();
		var mm = today.getMonth()+1; // January is 0
		var yyyy = today.getFullYear();
		if (mm.toString().length == 1)
			mm = '0'+mm+'';
		if (dd.toString().length == 1)
			dd = '0'+dd+'';
		var todaysDate = ''+yyyy+'-'+mm+'-'+dd+'';
		console.info("todaysDate: " + todaysDate);

		// Initialize the calendar
		//-----------------------------------------------------------------
		$('#calendar').fullCalendar({
			header: {
				left: 'prev,next today hideInstructions_button edit_button category_button',
				center: 'title',
				right: 'month,agendaWeek,agendaDay'
			},
			customButtons: {
				hideInstructions_button: {
					text: '?',
					click: function() {
						if ($scope.displayInstructions)
						{
							$scope.displayInstructions = false;
							try { document.getElementById('instructions').style.display = 'none'; } catch(err) { console.warn("[WARNING:611377] " + err.message); }
						}
						else
						{
							$scope.displayInstructions = true;
							try { document.getElementById('instructions').style.display = ''; } catch(err2) { console.warn("[WARNING:58297] " + err2.message); }
						}
					}
				},
				category_button: {
					text: 'Categories',
					click: function() {
						if ($scope.displayCategoryMenu)
						{
							$scope.displayCategoryMenu = false;
							try { document.getElementById('categoryMenuDIV').style.display = 'none'; } catch(err3) { console.warn("[WARNING:23242] " + err3.message); }
						}
						else
						{
							$scope.displayCategoryMenu = true;
							try { document.getElementById('categoryMenuDIV').style.display = ''; } catch(err4) { console.warn("[WARNING:2424] " + err4.message); }
						}
					}
				},
				edit_button: {
					text: $scope.data.editButton_EDIT,
					click: function() {
						if ($scope.data.hasEditRole)
							$scope.editButtonClicked(this);
						else
							this.parentNode.removeChild(this);

						$scope.clearEventWordWrapping();
					}
				}
			},
			height: "auto", // https://fullcalendar.io/docs/display/height/
			contentHeight: "auto",
			//aspectRatio: 1.35,
			defaultDate: todaysDate,
			timezone: $scope.data.calendarTimeZone, // Set in Server Script
			navLinks: true, // can click day/week names to navigate views
			selectHelper: true,
			eventClick: function(calEvent, jsEvent, view) {
				$scope.popupEventOptions(calEvent, jsEvent, view);
				$scope.categoryMenu_Cancel();
			},
			select: function(start, end) {
				var ed = $scope.createNewEvent(start, end);
				$scope.categoryMenu_Cancel();
			},
			eventResize: function(event, delta, revertFunc) {
				$scope.saveThisEvent(event.id, false, false, false, false, false);
				$scope.categoryMenu_Cancel();
			},
			eventDragStop: function(event, jsEvent, ui, view) {
				// Need this because revertDuration: 500 in fullcalendar.js
				// We need to wait for the duration to end before we save.
				// An extra 300 milliseconds should do it
				tOut = setTimeout(function(){ $scope.saveThisEvent(event.id, false, false, false, false); }, 800);
				$scope.categoryMenu_Cancel();
			},

			selectable: $scope.data.calendarCanBeEdited,
			editable: $scope.data.calendarCanBeEdited,
			droppable: $scope.data.calendarCanBeEdited, // this allows things to be dropped onto the calendar

			eventLimit: false, // allow "more" link when too many events
			drop: function(date, jsEvent, ui, resourceId) {
				$scope.xfer_QA_color_TO_event(this);
				$scope.categoryMenu_Cancel();
			},
			eventReceive: function(event) {
				event.backgroundColor = $scope.data.droppedEvent_bgc;
				event.textColor = $scope.data.droppedEvent_fgc;
				$scope.categoryMenu_Cancel();
				// Need internal id (_id) here
				$scope.saveThisEvent(event._id, true, false, false, true);
			},
			events: function(start, end, timezone, callback) {
				// Have to add this 'removeEvents' function in here so events don't double (display issue only)
				$('#calendar').fullCalendar('removeEvents');
				
				callback($scope.data.eventList);
				$(document).ready(function() { $scope.clearEventWordWrapping(); });
			}
		});
		
		theEventArray = $("#calendar").fullCalendar( 'clientEvents');
		$scope.setQuickAccessEventColor();
		$scope.applyContextMenu();
		$scope.setLeftColumnProperHeights();
		$scope.setLeftColumnProperWidths();
		$scope.toggleTheHelpButton("off");
		$scope.toggleTheCategoryButton("off");
		$scope.check_if_I_am_editing();
		$scope.setHowManyQuickAccessEvents();

		jsc = javaScript_Color_initialize_jsc_variable();
		$scope.initializeColorPicker();

		if ($scope.data.mySysID == 'b56edce2db81764c42307c28bf9619ac')
			$scope.calFullScreen(1);
		document.getElementById('calTitle').style.paddingLeft = ''+$scope.data.titlePaddingLeft+'px';

		$scope.clearEventWordWrapping();

		tOut = setTimeout(function(){ 
			$scope.build_new_eventCategory_selections('new_eventCategory');
			clearTimeout(tOut); }, 800);
	};

	$scope.refreshCalendar = function()
	{
		var cal = document.getElementById('calendar');
		if (cal)
		{
			$('#calendar').fullCalendar('removeEvents');
			$('#calendar').fullCalendar('removeEventSource', $scope.data.eventList);
			$('#calendar').fullCalendar('addEventSource', $scope.data.eventList);
			$('#calendar').fullCalendar('refetchEvents');
			theEventArray = $("#calendar").fullCalendar( 'clientEvents');
			$scope.setQuickAccessEventColor();
			$(document).ready(function() { $scope.clearEventWordWrapping(); });
		}
	};
	
	$scope.setWidth_CalList = function()
	{
		$(document).ready(function() { 
			try {
				var w = document.getElementById('external-events').offsetWidth;
				document.getElementById('mainCalSelDIV').style.paddingLeft = ''+w.toString()+'px';
			} catch(err) {}
		});
	};

	$scope.buildCalendarListView_CalSel = function()
	{
		var mainDiv = document.getElementById('mainCalSelDIV');

		if (!mainDiv)
		{
			alert("No table found!");
			return;
		}
		
		var validList = [];
		for (var v = 0; v < $scope.data.calendars.length; v++)
		{
			if ($scope.data.calendars[v].calID.toString() == $scope.data.gv__whichCalendar.toString())
				continue;
			
			validList.push({
				image:$scope.data.calendars[v].image,
				calID:$scope.data.calendars[v].calID,
				title:$scope.data.calendars[v].calTitle
			});
		}

		var newRow = false;
		var tr, td, url, html, calName, img, aDiv, imgDiv;

		var tbl = document.createElement('table');
		tbl.className = "tblStyle_CalSel";
		mainDiv.appendChild(tbl);

		for (var i = 0; i < validList.length; i++)
		{
			newRow = false;
			calName = validList[i].title.replace(' On-Call', '');
			
			if ((i % $scope.data.calListColumns) == 0)
				newRow = true;

			if (newRow)
				tr = document.createElement('tr');

			url = $scope.data.spURL + '?id=snsp_cal_-_calendar&sysparm_calID=' + validList[i].calID;

			td = document.createElement('td');
			aDiv = document.createElement('div');
			imgDiv = document.createElement('div');
			
			var aDiv_id = "aDiv_" + i.toString() + '';
			var imgDiv_id = "imgDiv_" + i.toString() + '';
			
			img = "url('" + validList[i].image + "')";

			if (tr)
				tr.appendChild(td);

			aDiv.textContent = calName;
			aDiv.className = "aDivStyle_CalSel";

			aDiv.id = aDiv_id;
			aDiv.setAttribute('calURL', url);
			imgDiv.id = imgDiv_id;
			imgDiv.className = "imgDivStyle_CalSel";
			imgDiv.setAttribute('calURL', url);

			imgDiv.onclick = function(){$scope.redirectToCalendar(this);};
			aDiv.onclick = function(){$scope.redirectToCalendar(this);};

			td.className = "tdStyle_CalSel grow_CalSel";
			imgDiv.style.backgroundImage = img;

			if (newRow)
				tbl.appendChild(tr);

			td.appendChild(aDiv);
			td.appendChild(imgDiv);
		}

		$scope.tmo();
		$scope.setWidth_CalList();
	};

	$scope.redirectToCalendar = function(whichCal)
	{
		if ($scope.data.editButtonStatus == $scope.data.editButton_EDIT)
		{
			var m = document.getElementById('masterBodyDiv');
			var cs = document.getElementById('mainCalSelDIV');
			if (m && cs)
			{
				cs.style.display = "none";
				
				while (m.firstChild)
					m.removeChild(m.firstChild);
				
				m.innerHTML = "<h1>...loading calendar</h1>";
				m.style.cssText = "text-align:center;margin-top:100px;";
			}
			window.location.href = whichCal.getAttribute('calURL');
		}
		else
		{
			alert("You must exit edit mode first.");
		}
	};
}