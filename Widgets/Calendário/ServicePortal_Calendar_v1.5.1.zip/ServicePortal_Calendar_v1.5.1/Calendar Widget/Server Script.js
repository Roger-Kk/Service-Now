/*  Version 1.5.1
https://community.servicenow.com/message/1152333

Change these 4 options as needed (per calendar)
*********************************************************/
var gv__calendarTable = 'u_sp_calendar';
var gv__calendarOptionsTable = 'u_sp_calendar_options';
var gv__calendarList = 'u_sp_calendar_listings';
var gv__calendarTimeZone = 'America/New_York';
/********************************************************/

//  DO NOT CHANGE THIS VALUE !!!!!!!!!
var gv__whichCalendar = 0;
/////////////////////////////////

(function() {

	if (!input)
		return;
	
	if (input && input.locationURL_CalVal)
	{
		gv__whichCalendar = input.locationURL_CalVal;
	}

	if (gv__whichCalendar == 0)
		return;
	
	var gr;
	data.gv__whichCalendar = gv__whichCalendar;

	var spURL = gs.getProperty('glide.servlet.uri') + "sp";
	data.spURL = spURL;

	var calendarListData = getCalendarListData();
	
	
	// ARE WE SUPPOSED TO BE SEEING THIS CALENDAR??
	var goodCal = false;
	data.goodCal = goodCal;
	for (var vc = 0; vc < calendarListData.length; vc++)
	{
		if (calendarListData[vc].calID.toString() == data.gv__whichCalendar.toString())
		{
			goodCal = true;
			data.goodCal = goodCal;
			break;
		}
	}
	if (!goodCal)
	{
		gs.addErrorMessage("This Calendar either does not exist or is hidden from view.");
		return;
	}
	
	data.calendars = calendarListData;

	if (input && input.RUNMEFIRST)
	{
		// Check if the Calendar Event table has the field, "u_number"
		// The u_number field will be used for the event ID, so it's *CRITICAL* this
		// field exists!
		var numberFieldFound = false;
		var grCheck = new GlideRecord('sys_dictionary');
		grCheck.addQuery('name', gv__calendarTable);
		grCheck.addQuery('element', 'u_number');
		grCheck.query();
		if (grCheck.next())
			numberFieldFound = 'true';

		// u_number field found.  Make sure it has a value.  If not, give it one!
		if (numberFieldFound)
		{
			var fCount = 0;
			// https://community.servicenow.com/thread/260128
			var grU = new GlideRecord(gv__calendarTable);
			grU.orderBy('sys_created_on');   
			grU.query();   
			while (grU.next())
			{
				if (grU.u_number)
					continue;
				fCount++;
				var nm = new NumberManager(gv__calendarTable);   
				grU.u_number = nm.getNextObjNumberPadded();   
				grU.autoSysFields(false);  // Do not update sys_updated_on, sys_updated_by, and sys_mod_count   
				grU.setWorkflow(false);    // Do not run any other business rules   
				grU.update();
			}
			if (fCount)
				gs.addInfoMessage(fCount + " records were auto-updated with a u_number value.");
		}
		else
		{
			// No u_number field.  Tell the user!
			gs.addErrorMessage("There is no 'u_number' field on the " + gv__calendarTable + " table!");
			return;
		}

		getEditMode(calendarListData);
		data.quickAccessEvents = buildQuickAccessEventList();
		data.eventList = buildCalEvents();
		data.saveAndSubmit = 0;
		data.mySysID = gs.getUserID().toString();
		data.categoryInformation = buildCategoryInfo();
		data.gv__calendarTimeZone = gv__calendarTimeZone;

		data.CalendarTitle = 'An Unidentified Calendar'; // Default

		// admin Role overrides all
		if (gs.hasRole('admin'))
			data.hasEditRole = true;
		else
			data.hasEditRole = false;

		// If not admin, check for role.  Set calendar title too.
		for (var q = 0; q < calendarListData.length; q++)
		{
			if (calendarListData[q].calID == gv__whichCalendar.toString())
			{
				data.CalendarTitle = calendarListData[q].calTitle;
				if (gs.hasRole(calendarListData[q].editRole))
					data.hasEditRole = true;
				break;
			}
		}
	}
	else if (input && input.locationURL_CalVal && !input.RUNMEFIRST)
	{
		data.mySysID = gs.getUserID().toString();
		getEditMode(calendarListData);

		// Is the calendar being edited and we don't know it yet?
		if (data.inEditMode == true && data.mySysID != data.personEditingSysID)
		{
			data.serverUpdateResponse = "The Calendar is currently being edited by " + data.personEditing;
			data.calendarCanBeEdited = false;
			return;
		}

		var i = 0;
		var a = input.calUpdate;
		var evtData = input.eventArray;
		var qry = "";
		var evtTitle = '', cat = '';
		var customColoredEvents = [];

		/******************************
		saveAndSubmit flags
******************************/
		if (input.saveAndSubmit == 1)
		{
			evtTitle = evtData[0].title;
			cat = evtData[0].category.toString();

			if (cat.length)
				evtTitle = evtTitle.replace('['+cat+'] ', '');

			gr = new GlideRecord(gv__calendarTable);
			gr.addQuery('u_calendar', gv__whichCalendar);
			gr.addQuery('u_number', evtData[0].id);
			gr.query();
			if (gr.next())
			{
				gr.setWorkflow(false);
				gr.u_title = evtTitle;
				gr.u_start = evtData[0].start;
				gr.u_end = evtData[0].end;
				gr.u_user = evtData[0].userSysID;
				gr.u_backgroundcolor = evtData[0].backgroundColor;
				gr.u_textcolor = evtData[0].textColor;
				gr.u_category = cat;
				gr.update();
			}

			data.eventList = buildCalEvents();
			data.iGotUpdated = 1;
			data.saveAndSubmit = 0;
		}
		else if (input.saveAndSubmit == 2)
		{
			gr = new GlideRecord(gv__calendarOptionsTable);
			gr.addQuery('u_calendar', gv__whichCalendar);
			gr.addQuery('u_show_in_qae_column', 'true');
			gr.addQuery('u_calendar', gv__whichCalendar);
			gr.query();
			while (gr.next())
			{
				for (i = 0; i < a.length; i++)
				{
					if (gr.u_quick_access_event_title.toString() == a[i].quickAccessEvent.toString())
					{
						gr.u_backgroundcolor = a[i].bgc;
						gr.u_textcolor = a[i].fgc;
						gr.u_trigger_event_title = a[i].quickAccessEvent;
						gr.u_user = a[i].user;
						gr.update();
					}
				}
			}

			data.quickAccessEvents = buildQuickAccessEventList();
			data.eventList = buildCalEvents();
			data.iGotUpdated = 1;
			data.saveAndSubmit = 0;
		}
		else if (input.saveAndSubmit == 3)
		{
			gr = new GlideRecord(gv__calendarOptionsTable);
			gr.addQuery('u_quick_access_event_title', input.addQuickAccessEvent);
			gr.addQuery('u_calendar', gv__whichCalendar);
			gr.addQuery('u_active', 'true');
			gr.query();
			if (gr.next())
			{
				if (gr.u_show_in_qae_column.toString() == 'false')
				{
					//if (!stringsAreEqual(gr.u_quick_access_event_title.toString(), input.addQuickAccessEvent.toString()))
					//	gs.addInfoMessage("Different");

					gr.u_quick_access_event_title = input.addQuickAccessEvent; // Setting this in case they change CaSe
					gr.u_show_in_qae_column = 'true';
					gr.update();
				}
				else
					data.serverUpdateResponse = "Event is already in list.";
			}
			else
			{
				gr = new GlideRecord(gv__calendarOptionsTable);
				gr.initialize();
				gr.u_calendar = gv__whichCalendar;
				gr.u_active = 'true';
				gr.u_show_in_qae_column = 'true';
				gr.u_user = input.qae_userID;
				gr.u_quick_access_event_title = input.addQuickAccessEvent;
				gr.insert();
			}

			data.quickAccessEvents = buildQuickAccessEventList();
			data.iGotUpdated = 1;
			data.saveAndSubmit = 0;
		}
		else if (input.saveAndSubmit == 4)
		{
			gr = new GlideRecord(gv__calendarOptionsTable);
			gr.addQuery('u_quick_access_event_title', input.deleteQuickAccessEvent);
			gr.addQuery('u_calendar', gv__whichCalendar);
			gr.addQuery('u_active', 'true');
			gr.query();
			if (gr.next())
			{
				gr.u_show_in_qae_column = 'false';
				gr.update();
			}

			data.quickAccessEvents = buildQuickAccessEventList();
			data.iGotUpdated = 1;
			data.saveAndSubmit = 0;
		}
		else if (input.saveAndSubmit == 5)
		{
			gr = new GlideRecord(gv__calendarTable);
			gr.initialize();
			gr.setWorkflow(false);
			gr.u_calendar = gv__whichCalendar;
			gr.u_title = evtData.title;
			gr.u_start = evtData.start;
			gr.u_end = evtData.end;
			gr.u_user = evtData.userSysID;
			gr.u_backgroundcolor = evtData.backgroundColor;
			gr.u_textcolor = evtData.textColor;
			gr.u_category = evtData.category;

			var sysID = gr.insert();

			gr = new GlideRecord(gv__calendarTable);
			gr.get(sysID);

			data.serverUpdateResponse = gr.u_number.getDisplayValue();
			data.eventList = buildCalEvents();
			data.iGotUpdated = 1;
			data.saveAndSubmit = 0;
		}
		else if (input.saveAndSubmit == 6)
		{
			gr = new GlideRecord(gv__calendarTable);
			gr.addQuery('u_calendar', gv__whichCalendar);
			gr.addQuery('u_number', evtData);
			gr.query();
			if (gr.next())
			{
				gr.setWorkflow(false);
				gr.deleteRecord();
			}
			else
				data.serverUpdateResponse = "Unable to delete event ID " + evtData + " from the database.";

			data.eventList = buildCalEvents();
			data.iGotUpdated = 1;
			data.saveAndSubmit = 0;
		}
		else if (input.saveAndSubmit == 7)
		{
			var tmp;
			for (i = 0; i < a.length; i++)
			{
				gr = new GlideRecord(gv__calendarOptionsTable);
				gr.addQuery('u_active', true);
				gr.addQuery('u_calendar', gv__whichCalendar);
				gr.addQuery('u_option_type', 5);
				gr.addQuery('u_category_information', 'STARTSWITH', '|'+a[i].catO+'|');
				gr.query();
				if (gr.next())
				{
					gr.setWorkflow(false);

					// Are we removing?
					if (a[i].catN == '')
					{
						gr.deleteRecord();
						updateCurrentEventsWithChangedCategoryName(a[i].catO, a[i].catN);
						continue;
					}					

					tmp = gr.u_category_information.toString().replace('|'+a[i].catO+'|', '');
					gr.u_category_information = '|' + a[i].catN + '|' + tmp;
					gr.u_backgroundcolor = a[i].bgc;
					gr.u_textcolor = a[i].fgc;
					//gr.u_user = a[i].user;
					gr.update();

					if (a[i].catO != a[i].catN)
						updateCurrentEventsWithChangedCategoryName(a[i].catO, a[i].catN);
				}
				else
				{
					gr.initialize();
					gr.u_active = 'true';
					gr.u_calendar = gv__whichCalendar;
					gr.u_option_type = 5;
					gr.u_category_information = '|' + a[i].catN + '|';
					gr.u_backgroundcolor = a[i].bgc;
					gr.u_textcolor = a[i].fgc;
					gr.insert();
				}
			}

			data.categoryInformation = buildCategoryInfo();
			data.eventList = buildCalEvents();
			data.iGotUpdated = 1;
			data.saveAndSubmit = 0;
		}
		else if (input.saveAndSubmit == 8)
		{
			gr = new GlideRecord(gv__calendarOptionsTable);
			gr.initialize();
			gr.u_active = 'true';
			gr.u_calendar = gv__whichCalendar;
			gr.u_option_type = 5;
			gr.u_category_information = '|' + a[0].cat + '|';
			gr.u_backgroundcolor = a[0].bgc;
			gr.u_textcolor = a[0].fgc;
			gr.insert();

			data.categoryInformation = buildCategoryInfo();
			data.iGotUpdated = 1;
			data.saveAndSubmit = 0;
		}
		else if (input.toggleEditMode == "enter")
		{
			// Delete if editing (will be re-added if still in edit mode though)
			gr = new GlideRecord(gv__calendarList);
			gr.addQuery('u_calendar_id', gv__whichCalendar);
			gr.addNotNullQuery('u_editing');
			gr.query()
			if (gr.next())
			{
				gr.u_editing = '';
				gr.update();

				data.inEditMode = false;
				data.personEditing = '';
			}

			if (input.editButtonStatus == 'Stop Editing')
			{
				gr = new GlideRecord(gv__calendarList);
				gr.addQuery('u_calendar_id', gv__whichCalendar);
				gr.addNullQuery('u_editing');
				gr.query()
				if (gr.next())
				{
					gr.u_editing = gs.getUserID();
					gr.update();

					data.inEditMode = true;
					data.personEditing = gs.getUserDisplayName().toString();
				}
				else
				{
					// Oops, someone was editing.
					data.serverUpdateResponse = "Oops, someone was editing.";
				}
			}
			calendarListData = getCalendarListData();
			data.calendars = calendarListData;
			getEditMode(calendarListData);
		}
		else if (input.toggleEditMode == "forcedStopEdit")
		{
			gr = new GlideRecord(gv__calendarList);
			gr.addQuery('u_calendar_id', gv__whichCalendar);
			gr.addQuery('u_editing', gs.getUserID().toString())
			gr.query()
			if (gr.next())
			{
				gr.u_editing = '';
				gr.update();
				data.serverUpdateResponse = "You were still in Edit mode, but now you're not.  You're welcome :)";
			}
			calendarListData = getCalendarListData();
			data.calendars = calendarListData;
			getEditMode(calendarListData);
		}
	}
})();

function buildQuickAccessEventList()
{
	var quickAccessEventList = [];
	var gr = new GlideRecord(gv__calendarOptionsTable);
	gr.addQuery('u_active', true);
	gr.addQuery('u_calendar', gv__whichCalendar);
	gr.addQuery('u_show_in_qae_column', true);
	gr.addNotNullQuery('u_quick_access_event_title');
	gr.query();
	while (gr.next())
	{
		quickAccessEventList.push({
			title:gr.u_quick_access_event_title.toString(),
			bgc:gr.u_backgroundcolor.toString(),
			fgc:gr.u_textcolor.toString(),
			user:gr.u_user.toString()
		});
	}
	return quickAccessEventList;
}

function getEditMode(calendars)
{
	var inEditMode = false;
	var amIediting = false;
	var personEditing = "";
	var personEditingSysID = "";

	for (var q = 0; q < calendars.length; q++)
	{
		if (calendars[q].calID == gv__whichCalendar.toString())
		{
			if (calendars[q].editing.toString().length)
			{
				inEditMode = true;
				personEditing = calendars[q].editing;
				personEditingSysID = calendars[q].editing_sysid;

				if (personEditingSysID == gs.getUserID().toString())
					amIediting = true;
			}
			break;
		}
	}
	
	data.inEditMode = inEditMode;
	data.personEditing = personEditing;
	data.personEditingSysID = personEditingSysID;
	data.amIediting = amIediting;
}

function buildCalEvents()
{
	var eventList = [];
	var r;
	var options = getCalOptions();
	var cat = '';
	var t = '', ot = '', bgc = '', fgc = '';
	var gr = new GlideRecord(gv__calendarTable);
	gr.addQuery('u_calendar', gv__whichCalendar);
	gr.query();
	while (gr.next())
	{
		bgc = gr.u_backgroundcolor.toString();
		fgc = gr.u_textcolor.toString();
		t = gr.u_title.toString();
		ot = gr.u_title.toString();
		cat = gr.u_category.toString();
		if (cat.length)
			t = '[' + cat + '] ' + gr.u_title.toString();

		r = getCatColors(cat);

		if (r.length)
		{
			bgc = r[0].bgc;
			fgc = r[0].fgc;
		}

		eventList.push({
			title:t,
			start:gr.u_start.toString(),
			end:gr.u_end.toString(),
			backgroundColor:bgc,
			textColor:fgc,
			hasOwnColor:gr.u_has_own_color.toString(),
			category:gr.u_category.toString(),
			userSysID:gr.u_user.toString(),
			id:gr.u_number.toString()
		});
	}

	//	for (var e = 0; e < eventList.length; e++)
	//	{
	//		for (var o = 0; o < options.length; o++)
	//		{
	//			if (eventList[e].title == options[o].trigger && eventList[e].hasOwnColor == 'false')
	//			{
	//				eventList[e].backgroundColor = options[o].bgc;
	//				eventList[e].textColor = options[o].fgc;
	//			}
	//		}
	//	}

	return eventList;
}

function stringsAreEqual(a,b)
{
	if (typeof(a) != 'string' || typeof(b) != 'string')
		return false;

	var a_l = a.length;
	var b_l = b.length;

	if (a_l != b_l)
		return false;

	var a_ary = a.split();
	var b_ary = b.split();

	// Okay, same length.  Let's compare
	for (var i = 0; i < a_ary.length; i++)
	{
		if (a_ary[i].charCodeAt() != b_ary[i].charCodeAt())
			return false;
	}
	return true;
}

function getCatColors(val)
{
	var r = [];
	var gr = new GlideRecord(gv__calendarOptionsTable);
	gr.addQuery('u_active', true);
	gr.addQuery('u_calendar', gv__whichCalendar);
	gr.addQuery('u_option_type', 5);
	gr.addQuery('u_category_information', 'STARTSWITH', '|'+val+'|');
	gr.query();
	if (gr.next())
		r.push({
			bgc:gr.u_backgroundcolor.toString(),
			fgc:gr.u_textcolor.toString()
		});

	return r;
}

function getCalOptions()
{
	var options = [];
	var gr = new GlideRecord(gv__calendarOptionsTable);
	gr.addQuery('u_active', true);
	gr.addQuery('u_calendar', gv__whichCalendar);
	gr.query();
	while (gr.next())
	{
		options.push({
			trigger:gr.u_trigger_event_title.toString(),
			bgc:gr.u_backgroundcolor.toString(),
			fgc:gr.u_textcolor.toString(),
			user:gr.u_user.toString()
		});
	}
	return options;
}

function updateCurrentEventsWithChangedCategoryName(O, N)
{
	var gr = new GlideRecord(gv__calendarTable);
	gr.addQuery('u_calendar', gv__whichCalendar);
	gr.addQuery('u_category', O);
	gr.query();
	while (gr.next())
	{
		gr.setWorkflow(false);
		gr.u_category = N;
		gr.update();
	}
}

function buildCategoryInfo()
{
	//  Name          | image
	// |Test2 Category|spriteSheet2.png,9,9
	var catInfo = [];
	var inf = '', name = '', bgc = '', fgc = '';
	var gr = new GlideRecord(gv__calendarOptionsTable);
	gr.addQuery('u_active', true);
	gr.addQuery('u_calendar', gv__whichCalendar);
	gr.addQuery('u_option_type', 5);
	gr.query();
	while (gr.next())
	{
		inf = gr.u_category_information.toString();

		catInfo.push({
			info:inf,
			name:inf.split('|')[1].toString(),
			bgc:gr.u_backgroundcolor.toString(),
			fgc:gr.u_textcolor.toString(),
			image:inf.split('|')[2].toString()
		});
	}
	return catInfo;
}

function getCalendarListData()
{
	var calendars = [];
	gr = new GlideRecord(gv__calendarList);
	gr.addQuery('u_appear_on_list', 'true');
	gr.orderBy('u_calendar_id');
	gr.query();
	while (gr.next())
	{
		var userEditing = '';
		var userEditing_sysid = '';

		if (gr.u_editing.toString().length)
		{
			userEditing = gr.u_editing.name.toString();
			userEditing_sysid = gr.u_editing.sys_id.toString();
		}

		calendars.push({
			image:gr.u_image.name.toString(),
			calID:gr.u_calendar_id.toString(),
			editRole:gr.u_edit_role.getDisplayValue().toString(),
			calTitle:gr.u_calendar_title.toString(),
			editing:userEditing,
			editing_sysid:userEditing_sysid
		});
	}

	return calendars;
}